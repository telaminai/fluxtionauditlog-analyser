package com.example.myapp;

import com.example.myapp.event.*;
import com.example.myapp.generated.MarketProcessor;
import com.telamin.fluxtion.runtime.DataFlow;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class MarketProcessorTest {

    @Test
    void buildsAndAcceptsEvents() {
        DataFlow flow = new MarketProcessor();
        flow.init();
        assertNotNull(flow);
        flow.onEvent(new PriceTick("demo", 1.0));
        // No exception = the graph built and dispatched. Add assertions on your
        // node's state once it does real work.
    }
}
