# Project agent entry

Read [PROJECT.md](PROJECT.md), then the task runbook it names. Agree predictions before execution. The design, source and current evidence determine project state.
