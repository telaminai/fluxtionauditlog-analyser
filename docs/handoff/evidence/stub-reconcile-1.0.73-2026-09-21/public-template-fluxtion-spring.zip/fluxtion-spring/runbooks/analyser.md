# Shared evidence canvas

Open .analyser/project.fluxtion-settings in your analyser. Use its Connect AI client action to configure this project's local LLM for that actual instance; no fixed port or machine-specific .mcp.json ships in this download.

Read context.runbooks, then open the relevant source/design and producer reports. The Spring XML is at src/main/fluxtion/designer/application-context.xml. Generated graphs, diagnostics and audit logs are expected outputs until a successful producer run creates them. Never treat a path as proof they exist or are current.

Load matching graph/log evidence and compare measured values with predictions. Use reports for record-anchored evidence and spotlights for attributed explanation. A screenshot checks placement; an action echo alone cannot establish what the human sees.

When reopening the project, inspect loaded versus saved state and explicitly restore available evidence. Missing or changed inputs must be resolved before reusing old conclusions. The analyser does not build, deploy or run your application.
