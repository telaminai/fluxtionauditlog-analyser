# fluxtion-spring: start here

This project is an embedded Fluxtion application, with its design declared in Spring XML.
Use a local LLM as a design partner: agree requirements and predictions, follow the applicable runbook, then compare measured results. A guided walkthrough is an optional exercise, not an execution mode.

## Prerequisites and versions

Use Java 21 and the included Maven wrapper. The POM is authoritative for resolved dependencies: Fluxtion BOM 1.0.72; local starter 1.0.73 is pinned by fluxtion-authoring.json.
Generation prerequisites depend on the selected backend. Read README and any emitted preflight/setup script before building; an unavailable tool coordinate is a provisioning failure, not successful validation. Do not put keys in this project.

## Choose a task

- [build-and-verify](runbooks/build.md): Build, run and check expected results independently.
- [spring-authoring](RUNBOOK.md): Validate XML, reconcile owned source and read current producer results.
- [shared-evidence-canvas](runbooks/analyser.md): Connect a real analyser instance; open design and evidence, create reports.

## Reference

Generated comments follow [comment contract 1](runbooks/comment-contract.json); [provenance](runbooks/comment-contract-manifest.json) identifies the tool coordinate and resource digest. [Spring field contract](https://fluxtion-playground.dev/spring-authoring/contract.md) and [agent entry](https://fluxtion-playground.dev/CLAUDE.md). These live reference pointers are not proof of compatibility: compare their version requirements with this project's POM. For local authoring, use the contract bundled with the pinned starter when available; stop on unsupported declarations.

The LLM runs commands through its own tools. The analyser displays design, diagnostics, logs and reports and does not execute the application. When returning, reread this file, the design and current results; a reopened view does not restore an LLM conversation.
