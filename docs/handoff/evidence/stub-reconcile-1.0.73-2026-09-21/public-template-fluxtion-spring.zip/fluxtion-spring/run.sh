#!/bin/bash
# Run the Fluxtion app. Builds the fat jar on first run; no --add-opens needed (Fluxtion 1.0 runtime),
# matching the IntelliJ run config (FluxtionMain.xml, no VM args).
set -e
cd "$(dirname "${BASH_SOURCE[0]}")"
JAR="target/fluxtion-spring-1.0.0-SNAPSHOT.jar"
[ -f "$JAR" ] || ./mvnw -q package -DskipTests
exec java -jar "$JAR"
